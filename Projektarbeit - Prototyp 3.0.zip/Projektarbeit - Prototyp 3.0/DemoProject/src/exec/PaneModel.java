package exec;

public class PaneModel {
    private double posX;
    private double posY;
    private double ZwischenwertX;//Zwischenwert der X Rechnung
    private double ZwischenwertY;//Zwischenwert der Y Rechnung
    private double currX;//Jetzige Maus Poition X
    private double currY;//Jetzige Maus Position Y
    private double posXNode;//Jetzige Node Pos X
    private double posYNode;//Jetzige Node Pos Y
    private double nodeXNeu;//Neue Node Position X
    private double nodeYNeu;//Neue Node Position Y
    private double XLineEnd;//Ende eines Line Elements auf X
    private double YLineEnd;//Ende eines Line Elements auf Y


    //Getter/Setter für Node Position
    public void setzPosXNode(double x){

        this.posXNode=x;
    }
    public void setzPosYNode(double y){

        this.posYNode=y;
    }
    public double gibPosXNode(){

        return posXNode;
    }
    public double gibPosYNode(){

        return posYNode;
    }
    //Getter/Setter für Current
    public void setzCurrX(double x){

        this.currX=x;
    }
    public void setzCurrY(double y){

        this.currY=y;
    }
    public double gibCurrX(){

        return currX;
    }
    public double gibCurrY(){

        return currY;
    }

    //Getter/Setter für Pos
    public void setzX(double x){

        this.posX=x;
    }
    public void setzY(double y){

        this.posY=y;
    }
    public double gibX(){

        return posX;
    }
    public double gibY(){

        return posY;
    }

    //Getter/Setter für Next. Aktuell verwendet im FXML Controller
    /*public void setzNextX(double x){
        this.ZwischenwertX=x;
    }
    public void setzNextY(double y){
        this.ZwischenwertY=y;
    }
    public double gibNextX(){
        return ZwischenwertX;
    }
    public double gibNextY(){
        return ZwischenwertY;
    }*/

    //Getter/Setter für NodeX und NodeY
    public void setzNodeX(double x){

        this.nodeXNeu=x;
    }
    public void setzNodeY(double y){

        this.nodeYNeu=y;
    }
    public double gibNodeX(){

        return nodeXNeu;
    }
    public double gibNodeY(){

        return nodeYNeu;
    }
    //Getter/Setter für LineEnd----------------------------
    public void setzXLineEnd(double x){
        this.XLineEnd=x;
    }
    public void setzYLineEnd(double y){
        this.YLineEnd=y;
    }
    public double gibXLineEnd(){
        return XLineEnd;
    }
    public double gibYLineEnd(){
        return YLineEnd;
    }

    //Rechnungen vom Dragger
    public void ergebnisXYPressed(){
        ZwischenwertX=currX-posXNode;
        ZwischenwertY=currY-posYNode;
        System.out.println(currX+"x1");
    }
    public void ergebnisXYDragged(){
        System.out.println(currX+"x2");
        nodeXNeu=currX-ZwischenwertX;
        nodeYNeu=currY-ZwischenwertY;
    }
}
