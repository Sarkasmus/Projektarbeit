package exec;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;


import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

public class PaneController implements EventHandler<ActionEvent> {
    //Controller für alles was nicht FXML ist
    private PaneModel paneModel;
    private PaneView paneView;
    private GatterMain gatterMain;



    public PaneController(PaneView paneView, PaneModel paneModel, GatterMain gatterMain) {
        this.paneView = paneView;
        this.paneModel = paneModel;
        this.gatterMain = gatterMain;
        paneView.getPicturePane().
                setOnMousePressed(this::handleMousePressed);
        paneView.getPicturePane().
                setOnMouseDragged(this::handleMouseDragged);
        paneView.getPicturePane().
                setOnMouseReleased(this::handleMouseReleased);
    }
    public PaneView createNewFenster(){
        paneView.calculateButton.addEventHandler(ActionEvent.ACTION, this);
        paneView.clearButton.addEventHandler(ActionEvent.ACTION, this);
        PaneView createNewFenster = createNewFenster();
        return createNewFenster;
    }

    @Override
    public void handle(ActionEvent event) {
        Object actionSource = event.getSource();
        if (actionSource == paneView.calculateButton) {
            createUND();
        } else if (actionSource==paneView.clearButton) {
            clear();
            
        }
    }


    private UND createUND() {
        UND undGatter = new UND();

        undGatter.setA(paneView.getA());
        undGatter.setB(paneView.getB());
        undGatter.getAusgabe();

        return createUND();

    }
    private void clear(){
        paneView.clearAllFields();
    }
    public void handleMousePressed(MouseEvent mouseEvent) {
        if(mouseEvent.getButton()==MouseButton.PRIMARY) {
            drag();
        }/** Wird die rechte Maustatste gedrückt, wird der deleter angewandt. */
        if (mouseEvent.getButton()== MouseButton.SECONDARY){
            paneView.getPicturePane().getChildren().forEach(this::deleter);
        }
    }
    public void handleMouseDragged(MouseEvent mouseEvent) {
    }
    public void handleMouseReleased(MouseEvent mouseEvent){
    }
    public void drag(){
        paneView.getPicturePane().getChildren().forEach(this::dragger);
    }
    private void deleter(Node node){
        node.setOnMousePressed(event -> {
            if(event.getButton()== MouseButton.SECONDARY) {
                paneView.getPicturePane().getChildren().remove(node);
            }
        });
    }
    private void dragger(Node node){
        node.setOnMousePressed(event -> {
            paneModel.setzCurrX(event.getX());
            paneModel.setzCurrY(event.getY());
            paneModel.setzPosXNode(node.getTranslateX());
            paneModel.setzPosYNode(node.getTranslateY());
            paneModel.ergebnisXYPressed();
        });
        node.setOnMouseDragged(event -> {
            paneModel.setzCurrX(event.getX());
            paneModel.setzCurrY(event.getY());
            paneModel.ergebnisXYDragged();
            node.setTranslateX(paneModel.gibNodeX());
            node.setTranslateY(paneModel.gibNodeY());
        });
    }

    /*public void BeispielAnzeigen(ActionEvent actionEvent){

    }*/





}
