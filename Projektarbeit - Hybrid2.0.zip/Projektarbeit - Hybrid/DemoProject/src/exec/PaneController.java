package exec;

import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;

public class PaneController {
    //Controller für alles was nicht FXML ist
    private PaneModel paneModel;
    private PaneView paneView;

    public PaneController(PaneView paneView, PaneModel paneModel) {
        this.paneView = paneView;
        this.paneModel = paneModel;
        paneView.getPicturePane().
                setOnMousePressed(this::handleMousePressed);
        paneView.getPicturePane().
                setOnMouseDragged(this::handleMouseDragged);
        paneView.getPicturePane().
                setOnMouseReleased(this::handleMouseReleased);
    }
    public void handleMousePressed(
            MouseEvent mouseEvent) {System.out.println("Mouse pressed!");
    }
    public void handleMouseDragged(
            MouseEvent mouseEvent) {System.out.println("Mouse dragged!");
    }
    public void handleMouseReleased(MouseEvent mouseEvent){
        System.out.println("Mouse released!");
        Rectangle rectangle =
                new Rectangle(mouseEvent.getX(),
                        mouseEvent.getY(),10,10);
        paneView.getPicturePane().getChildren().add(rectangle);
    }


}
