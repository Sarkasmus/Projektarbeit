package exec;

import javafx.scene.Group;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Translate;

public class PaneView {
    private PaneModel paneModel;
    private Pane picturePane;
    private Color currentFillColor = Color.BLACK;

    public PaneView(Pane picturePane, PaneModel paneModel,
                    double width, double height){
        this.picturePane = picturePane;
        picturePane.setPrefSize(width,height);
        this.paneModel = paneModel;
        currentFillColor = Color.rgb(245,85,0,1);

    }
    public Pane getPicturePane(){
        return picturePane;
    }
    public void setCurrentFillColor(Color currentFillColor){

        this.currentFillColor = currentFillColor;
    }
    public void addUndGroup(double x,double y){
        Group group=createPanePane(x,y);
        picturePane.getChildren().add(group);
        System.out.println("paneview");
    }
    private Pane createPane(){//Test zum kreieren einer nicht angemeldeten Pane
        Pane testPane=new Pane();
        testPane.setPrefHeight(50);
        testPane.setPrefWidth(50);
        testPane.setStyle("-fx-background-color:BLACK;");
        return testPane;
    }
    private Pane panePane(){//Gehört zum oben genannten Test dazu
        Pane klein=new Pane();
        klein.setPrefHeight(5);
        klein.setPrefWidth(10);
        klein.setStyle("-fx-background-color:RED;");
        return klein;
    }
    private Group createPanePane(double x,double y){//Führt die Testpanes zusammen.
        Pane Gros=createPane();
        Pane Klein=panePane();
        Pane KleinUnten=panePane();
        Pane KleinUntenRechts=panePane();
        //Translation der Pane oben links
        Translate transOL=new Translate(-5,5);
        Klein.getTransforms().add(transOL);
        //Translation der Pane unten links
        Translate transUL=new Translate(-5,40);
        KleinUnten.getTransforms().add(transUL);
        //Translation der Pane unten rechts
        Translate transUR=new Translate(45,40);
        KleinUntenRechts.getTransforms().add(transUR);
        //Zusammenführung der Panes und Rückgabe des neuen Objekts
        Group undBaustein=new Group(Gros,Klein,KleinUnten,KleinUntenRechts);
        undBaustein.setLayoutX(x);
        undBaustein.setLayoutY(y);
        return undBaustein;
    }
}
