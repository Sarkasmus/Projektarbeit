package exec;

import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;

import java.lang.annotation.Target;

public class PaneController {
    //Controller für alles was nicht FXML ist
    private PaneModel paneModel;
    private PaneView paneView;
    private double nextX;
    private double nextY;

    public PaneController(PaneView paneView, PaneModel paneModel) {
        this.paneView = paneView;
        this.paneModel = paneModel;
        paneView.getPicturePane().
                setOnMousePressed(this::handleMousePressed);
        paneView.getPicturePane().
                setOnMouseDragged(this::handleMouseDragged);
        paneView.getPicturePane().
                setOnMouseReleased(this::handleMouseReleased);
        //paneView.getPicturePane().getChildren().forEach(this::dragger);
    }
    public void handleMousePressed(MouseEvent mouseEvent) {
        double x=mouseEvent.getX();
        double y=mouseEvent.getY();
        System.out.println("Mouse pressed!");
        System.out.println(x+""+y);
        nextX=x-paneView.gibX();
        nextY=y-paneView.gibY();
    }
    public void handleMouseDragged(MouseEvent mouseEvent) {
        System.out.println("Mouse dragged!");
        paneView.setzX(mouseEvent.getX()-nextX);
        paneView.setzY(mouseEvent.getY()-nextY);
        System.out.println(paneView.gibX()+""+paneView.gibY());
        paneView.machNeu();
    }
    public void handleMouseReleased(MouseEvent mouseEvent){
        System.out.println("Mouse released!");
    }


}
