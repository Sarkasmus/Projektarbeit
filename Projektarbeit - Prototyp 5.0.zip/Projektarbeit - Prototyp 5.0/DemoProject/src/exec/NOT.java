package exec;

import exec.Gatter;

public  class NOT extends Gatter {


    public boolean getAusgabeboolean() {
        return getInv();

    }
}