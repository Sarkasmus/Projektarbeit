package sample;

public class Mode {
}
