package exec;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import static javafx.application.Application.launch;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage)throws Exception{
    //GatterMain gatterMain = new GatterMain();
    Gatter gatter = new Gatter();
    MainView mainView = new MainView(primaryStage, gatter);// gatterMain);
    Controller controller = mainView.getMainViewFxmlLoader().getController();
    //controller.setGatterMain(gatterMain);
    controller.setGatter(gatter);
    controller.setMainView(mainView);


        //Lädt das FXML File
Parent root= FXMLLoader.load(getClass().getResource("demoProject.fxml"));
//Setzt den Titel der Stage
primaryStage.setTitle("Demo");
    }
    public static void main(String[] args) {
        launch(args);
    }
}