package exec;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;


import javafx.scene.input.MouseEvent;


import javax.swing.*;
import java.lang.annotation.Target;
public class PaneController implements EventHandler<ActionEvent> {
//public class PaneController {
    //Controller für alles was nicht FXML ist
    private PaneModel paneModel;
    private PaneView paneView;
    private Gatter gatter;



     public PaneController(PaneView paneView, PaneModel paneModel, Gatter gatter) {
        this.paneView = paneView;
        this.paneModel = paneModel;
        this.gatter = gatter;

         paneView.calculateButton.addEventHandler(ActionEvent.ACTION, this);
            System.out.println("klick");
    }
    @Override
    public void handle(ActionEvent event) {
        Object actionSource = event.getSource();
        if (actionSource == paneView.calculateButton) {
            createUND();
        }
    }
        private UND createUND() {
            UND undGatter = new UND();

            undGatter.setA(paneView.getA());
            undGatter.setB(paneView.getB());
            undGatter.getAusgabe();

            return undGatter;

    }




    public void handleMousePressed(MouseEvent mouseEvent) {
        test();
    }
    public void handleMouseDragged(MouseEvent mouseEvent) {

    }
    public void handleMouseReleased(MouseEvent mouseEvent){

    }
    public void test(){
        paneView.getPicturePane().getChildren().forEach(this::dragger);
    }
    private void dragger(Node node){
        node.setOnMousePressed(event -> {
            paneModel.setzCurrX(event.getX());
            paneModel.setzCurrY(event.getY());
            paneModel.setzPosXNode(node.getTranslateX());
            paneModel.setzPosYNode(node.getTranslateY());
            paneModel.ergebnisXYPressed();
        });
        node.setOnMouseDragged(event -> {
            paneModel.setzCurrX(event.getX());
            paneModel.setzCurrY(event.getY());
            paneModel.ergebnisXYDragged();
            node.setTranslateX(paneModel.gibNodeX());
            node.setTranslateY(paneModel.gibNodeY());
        });
    }



    /*public void BeispielAnzeigen(ActionEvent actionEvent){

    }*/
/*
         paneView.clearButton.setOnAction((new EventHandler<ActionEvent>() {
             @Override
             public void handle(ActionEvent event) {
                 //clear();
             }
         }));
        /*

 */
         /*
         private void clear() {
             gatterMain.clear();
             paneView.clearAllFields();
         }

         */




}
