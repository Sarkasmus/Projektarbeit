package exec;

import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class PaneView {
    private PaneModel paneModel;
    private Pane picturePane;
    private Stage stage;
    private Scene scene;
    //private ComboBox<Integer> comboa;
    //private ComboBox<Integer> combob;
    private TextField operanda;
    private TextField operandb;
    public Button calculateButton;
    public Button clearButton;
    private TextField ausgabeText;
    private Gatter gatter;
    private UND undGatter;

    public PaneView(Pane picturePane, PaneModel paneModel, Gatter gatter, double width, double height){
        //public PaneView(Pane picturePane,PaneModel paneModel, double width, double height){
        this.picturePane = picturePane;
        picturePane.setPrefSize(width,height);
        this.paneModel = paneModel;
        this.gatter = gatter;
        this.undGatter = new UND();
        createNewFenster();
    }
    /*public void clearAllFields(){
        a.clear();
        operandb.clear();
        //ausgabeLabel.clear();
    }

     */
    public Pane getPicturePane(){

        return picturePane;
    }

    public int getOperanda() {

        return Integer.parseInt(operanda.getText());
    }

    public int getOperandb() {

        return Integer.parseInt(operandb.getText());
    }


/*
    public ComboBox<Integer> getComboa() {
        return comboa;
    }

    public ComboBox<Integer> getCombob() {
        return combob;
    }

 */

    public Button getCalculateButton() {
        return calculateButton;
    }



    public void setAusgabeText(int ausgabe){

        ausgabeText.setText(String.valueOf(ausgabe));
    }
    

    public void addUndGroup(){      // Erstellung der Group für die UND Operatoren und die jeweilige änderung der Koordinaten
        Group group=createPanePane();
        group.setTranslateX(paneModel.gibX());
        group.setTranslateY(paneModel.gibY());
        picturePane.getChildren().add(group);

    }
    private Pane createPane() {//Test zum kreieren einer nicht angemeldeten Pane
        Pane testPane = new Pane();
        testPane.setPrefHeight(50);
        testPane.setPrefWidth(50);
        testPane.setStyle("-fx-background-color:BLACK;");
        //testPane.setOnMouseClicked(event -> createNewFenster());
        return testPane;
    }
    private Pane panePane(){//Gehört zum oben genannten Test dazu
        Pane klein=new Pane();
        klein.setPrefHeight(5);
        klein.setPrefWidth(10);
        klein.setStyle("-fx-background-color:RED;");
        return klein;
    }
    private Group createPanePane(){//Führt die Testpanes zusammen.
        Pane Gros=createPane();
        Pane Klein=panePane();
        Pane KleinUnten=panePane();
        Pane KleinUntenRechts=panePane();
        //Translation der Pane oben links
        Translate transOL=new Translate(-5,5);
        Klein.getTransforms().add(transOL);
        //Translation der Pane unten links
        Translate transUL=new Translate(-5,40);
        KleinUnten.getTransforms().add(transUL);
        //Translation der Pane unten rechts
        Translate transUR=new Translate(45,40);
        KleinUntenRechts.getTransforms().add(transUR);
        //Zusammenführung der Panes und Rückgabe des neuen Objekts
        Group undBaustein=new Group(Gros,Klein,KleinUnten,KleinUntenRechts);
        undBaustein.setTranslateX(paneModel.gibX());
        undBaustein.setTranslateY(paneModel.gibY());
        return undBaustein;
    }

    public void createNewFenster() {
        //this.gatterMain = gatterMain;
        Stage logikFenster = new Stage();
        //FlowPane root = new FlowPane();
        //Scene scene = new Scene(root, 200, 200);
        logikFenster.setScene(scene);
        logikFenster.setTitle("Fenster");
        operanda = new TextField();
        operandb = new TextField();
        ausgabeText = new TextField();
        ausgabeText.setEditable(false);
        calculateButton = new Button("Calculate");
        clearButton = new Button("clear");

        Label aLabel = new Label("a=");
/*
        comboa= new ComboBox<>();
        comboa.getItems().addAll(0, 1);
        comboa.setValue(0);
        */



        Label bLabel = new Label(" b=");
/*
        combob= new ComboBox<>();
        combob.getItems().addAll(0,1);
        combob.setValue(0);

 */
        Label ausgabeLabel = new Label(" Ausgabe =");

        calculateButton.setOnAction(event -> calculate());

       VBox root = new VBox(aLabel, operanda, bLabel, operandb, ausgabeLabel, ausgabeText, calculateButton, clearButton);
        //VBox root = new VBox(aLabel, comboa, bLabel, combob, ausgabeLabel, calculateButton, clearButton);
       Scene scene = new Scene(root, 300, 200);


        logikFenster.setScene(scene);
        logikFenster.show();


    }
    public void calculate() {

        int operanda = getOperanda();
        int operandb = getOperandb();

        undGatter.setA(operanda);
        undGatter.setB(operandb);

        int ausgabe = undGatter.getAusgabe();

        setAusgabeText(ausgabe);

    }



    private void addSceneShapes(Pane pane) {
        Label label = createLabel();
        Label label2 = createLabel2();
        Label label3 = createLabel3();
        Label label4 = createLabel4();
        Label label5 = createLabel5();
        Label label6 = createLabel6();
        Label label7 = createLabel7();
        Label label8 = createLabel8();

        Line line = createLine();
        Line line2 = createLine2();
        Line line3 = createLine3();
        Line line4 = createLine4();
        Rectangle rectangle = createRectangle();
        Circle circle = createCircle();

        Line line5 = createLine5();
        Line line6 = createLine6();
        Line line7 = createLine7();
        Line line8 = createLine8();
        Rectangle rectangle2 = createRectangle2();
        Circle circle2 = createCircle2();

        Line line9 = createLine9();
        Line line10 = createLine10();
        Line line11 = createLine11();
        Line line12 = createLine12();
        Line line13 = createLine13();
        Rectangle rectangle3 = createRectangle3();
        Circle circle3 = createCircle3();

        pane.getChildren().add(line);
        pane.getChildren().add(line2);
        pane.getChildren().add(line3);
        pane.getChildren().add(line4);
        pane.getChildren().add(rectangle);
        pane.getChildren().add(circle);

        pane.getChildren().add(line5);
        pane.getChildren().add(line6);
        pane.getChildren().add(line7);
        pane.getChildren().add(line8);
        pane.getChildren().add(rectangle2);
        pane.getChildren().add(circle2);


        pane.getChildren().add(line9);
        pane.getChildren().add(line10);
        pane.getChildren().add(line11);
        pane.getChildren().add(line12);
        pane.getChildren().add(line13);
        pane.getChildren().add(rectangle3);
        pane.getChildren().add(circle3);

        pane.getChildren().add(label);
        pane.getChildren().add(label2);
        pane.getChildren().add(label3);
        pane.getChildren().add(label4);
        pane.getChildren().add(label5);
        pane.getChildren().add(label6);
        pane.getChildren().add(label7);
        pane.getChildren().add(label8);

        animateLine(line);
        animateLine(line2);
        animateLine2(line3);
        animateLine(line4);

        animateLine(line5);
        animateLine(line6);
        animateLine2(line7);
        animateLine(line8);

        animateLine2(line9);
        animateLine(line10);
        animateLine3(line11);
        animateLine(line12);
        animateLine(line13);

    }

    // Erstellung der Beispiel Schaltung mit der jeweiligen Animation

    private Label createLabel(){
        Label label = new Label("A=1");
        label.setTextFill(Color.GREEN);
        label.setLayoutX(75);
        label.setLayoutY((15));
        return label;
    }
    private Label createLabel2(){
        Label label = new Label("B=0");
        label.setTextFill(Color.RED);
        label.setLayoutX(75);
        label.setLayoutY((115));
        return label;
    }
    private Label createLabel3(){
        Label label = new Label("C=0");
        label.setTextFill(Color.RED);
        label.setLayoutX(175);
        label.setLayoutY((100));
        return label;
    }
    private Label createLabel4(){
        Label label = new Label("D=1");
        label.setTextFill(Color.GREEN);
        label.setLayoutX(175);
        label.setLayoutY((125));
        return label;
    }
    private Label createLabel5(){
        Label label = new Label("E=1");
        label.setTextFill(Color.GREEN);
        label.setLayoutX(325);
        label.setLayoutY((100));
        return label;
    }
    private Label createLabel6(){
        Label label = new Label("&");
        label.setTextFill(Color.WHITE);
        label.setFont(Font.font(20));
        label.setLayoutX(120);
        label.setLayoutY(65);
        return label;
    }
    private Label createLabel7(){
        Label label = new Label("&");
        label.setTextFill(Color.WHITE);
        label.setFont(Font.font(20));
        label.setLayoutX(120);
        label.setLayoutY(165);
        return label;
    }
    private Label createLabel8(){
        Label label = new Label("&");
        label.setTextFill(Color.WHITE);
        label.setFont(Font.font(20));
        label.setLayoutX(270);
        label.setLayoutY(115);
        return label;
    }
    private Rectangle createRectangle(){
        Rectangle rectangle = new Rectangle(100, 50,50,50);
        rectangle.setStroke(Color.GREEN);
        rectangle.setFill((Color.BLACK));
        rectangle.setStrokeWidth(2);
        return rectangle;
    }

    private Circle createCircle() {
        Circle circle = new Circle(10);
        circle.setStroke(Color.RED);
        circle.setStrokeWidth(2);
        circle.setLayoutX(150);
        circle.setLayoutY(75);
        return circle;
    }

    private Line createLine() {
        Line line = new Line();
        line.setStartX(80);
        line.setStartY(60);
        line.setEndX(100);
        line.setEndY(60);
        line.setStrokeWidth(2);
        line.setStroke(Color.GREEN);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine2() {
        Line line = new Line();
        line.setStartX(80);
        line.setStartY(90);
        line.setEndX(100);
        line.setEndY(90);
        line.setStrokeWidth(2);
        line.setStroke(Color.GREEN);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine3() {
        Line line = new Line();
        line.setStartX(80);
        line.setStartY(30);
        line.setEndX(80);
        line.setEndY(83);
        line.setStrokeWidth(2);
        line.setStroke(Color.GREEN);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine4() {
        Line line = new Line();
        line.setStartX(150);
        line.setStartY(75);
        line.setEndX(200);
        line.setEndY(75);
        line.setStrokeWidth(2);
        line.setStroke(Color.RED);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Rectangle createRectangle2(){
        Rectangle rectangle = new Rectangle(100, 150,50,50);
        rectangle.setStroke(Color.RED);
        rectangle.setFill((Color.BLACK));
        rectangle.setStrokeWidth(2);
        return rectangle;
    }
    private Circle createCircle2() {
        Circle circle = new Circle(10);
        circle.setStroke(Color.GREEN);
        circle.setStrokeWidth(2);
        circle.setLayoutX(150);
        circle.setLayoutY(175);
        return circle;
    }


    private Line createLine5() {
        Line line = new Line();
        line.setStartX(80);
        line.setStartY(160);
        line.setEndX(100);
        line.setEndY(160);
        line.setStrokeWidth(2);
        line.setStroke(Color.RED);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine6() {
        Line line = new Line();
        line.setStartX(80);
        line.setStartY(190);
        line.setEndX(100);
        line.setEndY(190);
        line.setStrokeWidth(2);
        line.setStroke(Color.RED);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine7() {
        Line line = new Line();
        line.setStartX(80);
        line.setStartY(130);
        line.setEndX(80);
        line.setEndY(183);
        line.setStrokeWidth(2);
        line.setStroke(Color.RED);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine8() {
        Line line = new Line();
        line.setStartX(150);
        line.setStartY(175);
        line.setEndX(200);
        line.setEndY(175);
        line.setStrokeWidth(2);
        line.setStroke(Color.GREEN);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }
    private Rectangle createRectangle3(){
        Rectangle rectangle = new Rectangle(250, 100,50,50);
        rectangle.setStroke(Color.RED);
        rectangle.setFill((Color.BLACK));
        rectangle.setStrokeWidth(2);
        return rectangle;
    }

    private Circle createCircle3() {
        Circle circle = new Circle(10);
        circle.setStroke(Color.GREEN);
        circle.setStrokeWidth(2);
        circle.setLayoutX(300);
        circle.setLayoutY(125);
        return circle;
    }

    private Line createLine9() {
        Line line = new Line();
        line.setStartX(207);
        line.setStartY(75);
        line.setEndX(207);
        line.setEndY(100);
        line.setStrokeWidth(2);
        line.setStroke(Color.RED);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine10() {
        Line line = new Line();
        line.setStartX(207);
        line.setStartY(110);
        line.setEndX(250);
        line.setEndY(110);
        line.setStrokeWidth(2);
        line.setStroke(Color.RED);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine11() {
        Line line = new Line();
        line.setStartX(207);
        line.setStartY(175);
        line.setEndX(207);
        line.setEndY(147);
        line.setStrokeWidth(2);
        line.setStroke(Color.GREEN);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine12() {
        Line line = new Line();
        line.setStartX(207);
        line.setStartY(140);
        line.setEndX(250);
        line.setEndY(140);
        line.setStrokeWidth(2);
        line.setStroke(Color.GREEN);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }

    private Line createLine13() {
        Line line = new Line();
        line.setStartX(300);
        line.setStartY(125);
        line.setEndX(450);
        line.setEndY(125);
        line.setStrokeWidth(2);
        line.setStroke(Color.GREEN);
        line.getStrokeDashArray().addAll(2.0, 7.0, 2.0, 7.0);
        return line;
    }


    private void animateLine(Line line) {
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(200), line);
        translateTransition.setByX(10);
        translateTransition.setCycleCount(Timeline.INDEFINITE);
        translateTransition.setAutoReverse(false);
        translateTransition.play();
    }
    private void animateLine2(Line line){
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(200), line);
        translateTransition.setByY(10);
        translateTransition.setCycleCount(Timeline.INDEFINITE);
        translateTransition.setAutoReverse(false);
        translateTransition.play();
    }
    private void animateLine3(Line line){
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(200), line);
        translateTransition.setByY(-10);
        translateTransition.setCycleCount(Timeline.INDEFINITE);
        translateTransition.setAutoReverse(false);
        translateTransition.play();
    }

    public void ViewExample() {

        showViewExample();
    }

    private Stage showViewExample() {   // Pane to draw on
        stage = new Stage(StageStyle.DECORATED);
        stage.setTitle("Beispiel Schaltung");
        Pane pane = new Pane();
        pane.setPrefWidth(600);
        pane.setPrefHeight(400);
        pane.setStyle("-fx-background-color: WHITE;");
        addSceneShapes(pane);
        AnchorPane root = new AnchorPane(pane);

        scene = new Scene(root,500, 400);
        stage.setScene(scene);
       /* primaryStage.setTitle("Beispiel: Aus NAND ein ODER");
        primaryStage.setScene(new Scene(root));
        primaryStage.show(); */
        stage.show();
        return stage;
    }

}