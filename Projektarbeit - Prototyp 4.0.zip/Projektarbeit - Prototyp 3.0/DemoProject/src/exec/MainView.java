package exec;

import javafx.event.Event;
import javafx.event.EventType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.lang.invoke.MethodHandle;

public class MainView {

    private FXMLLoader mainViewFxmlLoader;
    private Gatter gatter;
    private PaneMain paneMain;
    private PaneMain addUndGroup;

    public PaneMain getPaneMain() {

        return paneMain;
    }


    public FXMLLoader getMainViewFxmlLoader() {

        return mainViewFxmlLoader;
    }

    public MainView(Stage primaryStage, Gatter gatter)throws Exception{
        mainViewFxmlLoader = new FXMLLoader(getClass().getResource("demoProject.fxml"));
        Parent root = mainViewFxmlLoader.load();

        paneMain = new PaneMain();

        Pane output = (Pane) root.lookup("#output");
        output.getChildren().add(paneMain);


        Button BeispielButton = (Button) root.lookup("#BeispielButton");
        BeispielButton.setOnAction(event -> paneMain.ViewExample());



        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
}
