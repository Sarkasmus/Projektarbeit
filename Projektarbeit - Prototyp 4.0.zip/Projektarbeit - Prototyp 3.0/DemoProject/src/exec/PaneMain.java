package exec;

import javafx.scene.layout.Pane;

public class PaneMain extends Pane {
    PaneView paneView;
    PaneModel paneModel;
    Gatter gatter;


    public PaneMain(){
        paneModel = new PaneModel();
        paneView = new PaneView(this, paneModel, gatter, 600, 400);
        PaneController paneController = new PaneController(paneView, paneModel, gatter);
    }
    public void addUndGroup(UND und){ //Methode zur Erfassung und Erstellung der UND Group, mit dem Funktionstype boolean
        paneView.addUndGroup();
        //System.out.println("panemain");
    }

    public void ViewExample(){

        paneView.ViewExample();
    }
    public void setzX(double x){

        paneModel.setzX(x);
    }
    public void setzY(double y){

        paneModel.setzY(y);
    }
}
