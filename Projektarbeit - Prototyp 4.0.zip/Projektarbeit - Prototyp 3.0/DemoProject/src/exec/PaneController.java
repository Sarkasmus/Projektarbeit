package exec;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.event.Event;


import javafx.scene.input.MouseEvent;

import javax.swing.text.View;

public class PaneController  {
    //Controller für alles was nicht FXML ist
    private PaneModel paneModel;
    private PaneView paneView;
    private UND undGatter;


    public PaneController(PaneView paneView, PaneModel paneModel, Gatter gatter) {
        this.paneView = paneView;
        this.paneModel = paneModel;
        this.undGatter = new UND();

        paneView.getPicturePane().setOnMousePressed(this::handleMousePressed);
        paneView.getPicturePane().setOnMouseDragged(this::handleMouseDragged);
        paneView.getPicturePane().setOnMouseReleased(this::handleMouseReleased);
        //testPane.setOnMouseClicked(event -> createNewFenster());

        paneView.getPicturePane().setOnMouseClicked(event -> paneView.createNewFenster()
        );


/*
        paneView.calculateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                calculate();
                System.out.println("Test1");
            }
        });

 */



    }
    /*
    public void calculate() {
        int operanda = paneView.getOperanda();
        int operandb = paneView.getOperandb();

        undGatter.setA(operanda);
        undGatter.setB(operandb);

        int ausgabe = undGatter.getAusgabe();

        paneView.setAusgabeText(ausgabe);

    }

     */

/*
    private void clear(){
        paneView.clearAllFields();
    }

 */
    public void handleMousePressed(MouseEvent mouseEvent) {
        test();
    }
    public void handleMouseDragged(MouseEvent mouseEvent) {

    }
    public void handleMouseReleased(MouseEvent mouseEvent){

    }
    public void test(){
        paneView.getPicturePane().getChildren().forEach(this::dragger);
    }
    private void dragger(Node node) {
        node.setOnMousePressed(event -> {
            paneModel.setzCurrX(event.getX());
            paneModel.setzCurrY(event.getY());
            paneModel.setzPosXNode(node.getTranslateX());
            paneModel.setzPosYNode(node.getTranslateY());
            paneModel.ergebnisXYPressed();
        });
        node.setOnMouseDragged(event -> {
            paneModel.setzCurrX(event.getX());
            paneModel.setzCurrY(event.getY());
            paneModel.ergebnisXYDragged();
            node.setTranslateX(paneModel.gibNodeX());
            node.setTranslateY(paneModel.gibNodeY());
        });


    }

}
