package exec;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class PaneMain extends Pane {
    PaneView paneView;

    public PaneMain(){
        PaneModel paneModel = new PaneModel();
        paneView = new PaneView(this, paneModel, 600, 400);
        PaneController paneController = new PaneController(paneView, paneModel);

    }
    /*public void setCurrentFillColor(Color currentFillColor){
        paneView.setCurrentFillColor(currentFillColor);
    }*/
}
