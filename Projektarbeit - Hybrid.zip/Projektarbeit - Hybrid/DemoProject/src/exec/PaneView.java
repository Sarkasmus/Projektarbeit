package exec;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

public class PaneView {
    private PaneModel paneModel;
    private Pane picturePane;
    private Color currentFillColor = Color.BLACK;

    public PaneView(Pane picturePane, PaneModel paneModel,
                    double width, double height){
        this.picturePane = picturePane;
        picturePane.setPrefSize(width,height);
        this.paneModel = paneModel;
        currentFillColor = Color.rgb(245,85,0,1);
        addSceneBasicShapes(picturePane);
    }
    public Pane getPicturePane(){
        return picturePane;
    }
    public void setCurrentFillColor(Color currentFillColor){

        this.currentFillColor = currentFillColor;
    }
    private void addSceneBasicShapes(Pane pane){
        pane.getChildren().add(createCircle());
    }
    private Circle createCircle(){
        Circle circle = new Circle();
        circle.setCenterX(240);
        circle.setCenterY(120);
        circle.setRadius(100);
        circle.setStroke(Color.RED);
        circle.setStrokeWidth(3);
        circle.setFill(Color.WHITESMOKE);
        return circle;
    }
}
