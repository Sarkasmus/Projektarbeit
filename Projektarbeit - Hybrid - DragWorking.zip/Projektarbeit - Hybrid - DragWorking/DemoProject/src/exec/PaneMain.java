package exec;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class PaneMain extends Pane {
    PaneView paneView;
    PaneModel paneModel;


    public PaneMain(){
        paneModel = new PaneModel();
        paneView = new PaneView(this, paneModel, 600, 400);
        PaneController paneController = new PaneController(paneView, paneModel);
    }
    public void addUndGroup(){
        paneView.addUndGroup();
        //System.out.println("panemain");
    }
    public void setzX(double x){
        paneModel.setzX(x);
    }
    public void setzY(double y){
        paneModel.setzY(y);
    }
}
