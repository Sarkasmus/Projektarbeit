package exec;

import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;

import java.lang.annotation.Target;

public class PaneController {
    //Controller für alles was nicht FXML ist
    private PaneModel paneModel;
    private PaneView paneView;

    public PaneController(PaneView paneView, PaneModel paneModel) {
        this.paneView = paneView;
        this.paneModel = paneModel;
        paneView.getPicturePane().
                setOnMousePressed(this::handleMousePressed);
        paneView.getPicturePane().
                setOnMouseDragged(this::handleMouseDragged);
        paneView.getPicturePane().
                setOnMouseReleased(this::handleMouseReleased);
    }
    public void handleMousePressed(MouseEvent mouseEvent) {
        test();
    }
    public void handleMouseDragged(MouseEvent mouseEvent) {

    }
    public void handleMouseReleased(MouseEvent mouseEvent){

    }
    public void test(){
        paneView.getPicturePane().getChildren().forEach(this::dragger);
    }
    private void dragger(Node node){
        node.setOnMousePressed(event -> {
            paneModel.setzCurrX(event.getX());
            paneModel.setzCurrY(event.getY());
            paneModel.setzPosXNode(node.getTranslateX());
            paneModel.setzPosYNode(node.getTranslateY());
            paneModel.ergebnisXYPressed();
        });
        node.setOnMouseDragged(event -> {
            paneModel.setzCurrX(event.getX());
            paneModel.setzCurrY(event.getY());
            paneModel.ergebnisXYDragged();
            node.setTranslateX(paneModel.gibNodeX());
            node.setTranslateY(paneModel.gibNodeY());
        });
    }




}
